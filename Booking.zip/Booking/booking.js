// JavaScript для страницы бронирования

document.addEventListener('DOMContentLoaded', function() {
// Инициализация даты (минимум сегодня)
const dateInput = document.getElementById('date');
if (dateInput) {
const today = new Date().toISOString().split('T')[0];
dateInput.min = today;
dateInput.value = today;
}

// Загрузка данных столиков
loadTables();

// Обработка формы контактных данных
const contactForm = document.getElementById('contactForm');
if (contactForm) {
contactForm.addEventListener('submit', function(e) {
e.preventDefault();
submitBooking();
});
}
});

let selectedTable = null;
const tablesData = [
{ id: 1, number: 1, capacity: 2, location: 'У окна', available: true },
{ id: 2, number: 2, capacity: 4, location: 'Центр зала', available: false },
{ id: 3, number: 3, capacity: 2, location: 'Балкон', available: true },
{ id: 4, number: 4, capacity: 6, location: 'VIP зона', available: true },
{ id: 5, number: 5, capacity: 4, location: 'У окна', available: true },
{ id: 6, number: 6, capacity: 2, location: 'Терраса', available: false },
{ id: 7, number: 7, capacity: 8, location: 'Большой зал', available: true },
{ id: 8, number: 8, capacity: 4, location: 'Центр зала', available: true }
];

function loadTables() {
const tablesGrid = document.getElementById('tablesGrid');
if (!tablesGrid) return;

tablesGrid.innerHTML = '';

tablesData.forEach(table => {
const tableElement = document.createElement('div');
tableElement.className = `table-item ${table.available ? 'available' : 'booked'}`;
tableElement.innerHTML = `
<span class="table-number">#${table.number}</span>
<span class="table-capacity">${table.capacity} чел.</span>
`;

if (table.available) {
tableElement.addEventListener('click', () => selectTable(table));
}

tablesGrid.appendChild(tableElement);
});
}

function selectTable(table) {
selectedTable = table;

// Обновляем информацию о выбранном столике
document.getElementById('selectedTableText').textContent = `Выбран столик #${table.number}`;
document.getElementById('tableNumber').textContent = table.number;
document.getElementById('tableCapacity').textContent = `${table.capacity} человек`;
document.getElementById('tableLocation').textContent = table.location;

// Активируем кнопку "Далее"
const nextBtn = document.getElementById('nextBtn');
nextBtn.disabled = false;
nextBtn.classList.add('btn-primary');

// Сбрасываем выделение у всех столиков
document.querySelectorAll('.table-item').forEach(item => {
item.classList.remove('selected');
});

// Выделяем выбранный столик
const tableElements = document.querySelectorAll('.table-item');
tableElements[table.id - 1].classList.add('selected');
}

function checkAvailability() {
const date = document.getElementById('date').value;
const time = document.getElementById('time').value;
const guests = document.getElementById('guests').value;

if (!date || !time || !guests) {
alert('Пожалуйста, заполните все поля');
return;
}

// Переходим ко второму шагу
goToStep(2);
}

function goToStep(stepNumber) {
// Скрываем все шаги
document.querySelectorAll('.booking-step').forEach(step => {
step.classList.remove('active');
});

// Показываем нужный шаг
const targetStep = document.getElementById(`step${stepNumber}`);
if (targetStep) {
targetStep.classList.add('active');

// Прокручиваем к началу шага
targetStep.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
}

function nextStep() {
if (!selectedTable) {
alert('Пожалуйста, выберите столик');
return;
}

goToStep(3);
}

function prevStep() {
goToStep(2);
}

function submitBooking() {
const name = document.getElementById('name').value;
const phone = document.getElementById('phone').value;
const email = document.getElementById('email').value;

if (!name || !phone || !email) {
alert('Пожалуйста, заполните все обязательные поля');
return;
}

// Валидация email
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (!emailRegex.test(email)) {
alert('Пожалуйста, введите корректный email');
return;
}

// Валидация телефона
const phoneRegex = /^(\+7|8)[\s\-]?\(?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}$/;
if (!phoneRegex.test(phone)) {
alert('Пожалуйста, введите корректный номер телефона');
return;
}

// Заполняем сводку
document.getElementById('summaryDate').textContent = document.getElementById('date').value;
document.getElementById('summaryTime').textContent = document.getElementById('time').value;
document.getElementById('summaryGuests').textContent = document.getElementById('guests').value;
document.getElementById('summaryTable').textContent = `Столик #${selectedTable.number}`;
document.getElementById('summaryName').textContent = name;

// Переходим к подтверждению
goToStep(4);

// Имитация отправки данных на сервер
setTimeout(() => {
console.log('Бронирование отправлено:', {
date: document.getElementById('date').value,
time: document.getElementById('time').value,
guests: document.getElementById('guests').value,
table: selectedTable,
name: name,
phone: phone,
email: email
});
}, 500);
}

function printConfirmation() {
window.print();
}

// Отмена бронирования
document.querySelectorAll('.btn-cancel').forEach(button => {
button.addEventListener('click', function() {
if (confirm('Вы уверены, что хотите отменить это бронирование?')) {
const bookingCard = this.closest('.booking-card');
if (bookingCard) {
bookingCard.style.opacity = '0.5';
this.innerHTML = '<i class="fas fa-check"></i> Отменено';
this.disabled = true;
this.classList.remove('btn-cancel');

// Показываем сообщение об успешной отмене
alert('Бронирование успешно отменено');
}
}
});
});