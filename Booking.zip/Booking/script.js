// Основной файл JavaScript для всего сайта

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
// Мобильное меню
const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.querySelector('.nav-menu');

if (menuToggle && navMenu) {
menuToggle.addEventListener('click', function() {
navMenu.classList.toggle('active');
menuToggle.innerHTML = navMenu.classList.contains('active')
? '<i class="fas fa-times"></i>'
: '<i class="fas fa-bars"></i>';
});
}

// Плавная прокрутка для якорей
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
anchor.addEventListener('click', function(e) {
e.preventDefault();
const targetId = this.getAttribute('href');
if (targetId === '#') return;

const targetElement = document.querySelector(targetId);
if (targetElement) {
window.scrollTo({
top: targetElement.offsetTop - 80,
behavior: 'smooth'
});

// Закрываем мобильное меню если оно открыто
if (navMenu && navMenu.classList.contains('active')) {
navMenu.classList.remove('active');
menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
}
}
});
});

// Активация навигации в документации
const docNavLinks = document.querySelectorAll('.doc-nav a');
docNavLinks.forEach(link => {
link.addEventListener('click', function(e) {
e.preventDefault();
const targetId = this.getAttribute('href');
const targetSection = document.querySelector(targetId);

if (targetSection) {
// Убираем активный класс у всех ссылок
docNavLinks.forEach(l => l.classList.remove('active'));

// Добавляем активный класс текущей ссылке
this.classList.add('active');

// Прокручиваем к секции
window.scrollTo({
top: targetSection.offsetTop - 100,
behavior: 'smooth'
});
}
});
});

// Автоматическое обновление года в футере
const yearElement = document.querySelector('.footer-bottom p');
if (yearElement) {
const currentYear = new Date().getFullYear();
yearElement.innerHTML = yearElement.innerHTML.replace('2025', currentYear);
}
});