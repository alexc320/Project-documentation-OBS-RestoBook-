// JavaScript для страницы обратной связи

document.addEventListener('DOMContentLoaded', function() {
// Счетчик символов в текстовом поле
const messageTextarea = document.getElementById('message');
const charCountElement = document.getElementById('charCount');

if (messageTextarea && charCountElement) {
messageTextarea.addEventListener('input', function() {
const currentLength = this.value.length;
charCountElement.textContent = currentLength;

// Изменяем цвет при приближении к лимиту
if (currentLength > 900) {
charCountElement.style.color = '#dc3545';
} else if (currentLength > 700) {
charCountElement.style.color = '#ffc107';
} else {
charCountElement.style.color = '#28a745';
}
});
}

// Обработка загрузки файла
const fileInput = document.getElementById('attachment');
const fileInfoElement = document.getElementById('fileInfo');

if (fileInput && fileInfoElement) {
fileInput.addEventListener('change', function() {
if (this.files.length > 0) {
const file = this.files[0];
const fileSize = (file.size / 1024 / 1024).toFixed(2); // Размер в MB

if (fileSize > 10) {
alert('Файл слишком большой! Максимальный размер: 10 MB');
this.value = '';
fileInfoElement.classList.remove('show');
return;
}

fileInfoElement.innerHTML = `
<strong>Выбран файл:</strong> ${file.name}<br>
<strong>Размер:</strong> ${fileSize} MB<br>
<strong>Тип:</strong> ${file.type || 'Неизвестно'}
`;
fileInfoElement.classList.add('show');
} else {
fileInfoElement.classList.remove('show');
}
});
}

// Обработка FAQ аккордеона
const faqQuestions = document.querySelectorAll('.faq-question');

faqQuestions.forEach(question => {
question.addEventListener('click', function() {
const answer = this.nextElementSibling;
const isActive = this.classList.contains('active');

// Закрываем все открытые вопросы
document.querySelectorAll('.faq-question').forEach(q => {
q.classList.remove('active');
q.nextElementSibling.classList.remove('show');
});

// Если вопрос не был активен, открываем его
if (!isActive) {
this.classList.add('active');
answer.classList.add('show');
}
});
});

// Обработка формы обратной связи
const feedbackForm = document.getElementById('feedbackForm');
const successMessage = document.getElementById('successMessage');

if (feedbackForm) {
feedbackForm.addEventListener('submit', function(e) {
e.preventDefault();

// Валидация формы
if (!validateForm()) {
return;
}

// Сбор данных формы
const formData = new FormData(this);
const formDataObject = Object.fromEntries(formData.entries());

// Имитация отправки на сервер
console.log('Данные формы обратной связи:', formDataObject);

// Показываем сообщение об успешной отправке
showSuccessMessage();

// Очищаем форму
this.reset();

// Сбрасываем счетчик символов
if (charCountElement) {
charCountElement.textContent = '0';
charCountElement.style.color = '#28a745';
}

// Скрываем информацию о файле
if (fileInfoElement) {
fileInfoElement.classList.remove('show');
}
});
}
});

function validateForm() {
const name = document.getElementById('name').value.trim();
const email = document.getElementById('email').value.trim();
const subject = document.getElementById('subject').value;
const message = document.getElementById('message').value.trim();

// Проверка имени
if (name.length < 2) {
alert('Пожалуйста, введите ваше имя (минимум 2 символа)');
document.getElementById('name').focus();
return false;
}

// Проверка email
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (!emailRegex.test(email)) {
alert('Пожалуйста, введите корректный email адрес');
document.getElementById('email').focus();
return false;
}

// Проверка темы
if (!subject) {
alert('Пожалуйста, выберите тему обращения');
document.getElementById('subject').focus();
return false;
}

// Проверка сообщения
if (message.length < 10) {
alert('Пожалуйста, опишите вашу проблему или предложение более подробно (минимум 10 символов)');
document.getElementById('message').focus();
return false;
}

return true;
}

function showSuccessMessage() {
const successMessage = document.getElementById('successMessage');
if (successMessage) {
successMessage.style.display = 'flex';

// Генерация случайного номера обращения
const ticketNumber = 'FB-' + new Date().getFullYear() + '-' +
Math.floor(Math.random() * 10000).toString().padStart(5, '0');

const ticketElement = successMessage.querySelector('strong');
if (ticketElement) {
ticketElement.textContent = ticketNumber;
}

// Автоматическое скрытие через 10 секунд
setTimeout(() => {
closeSuccessMessage();
}, 10000);
}
}

function closeSuccessMessage() {
const successMessage = document.getElementById('successMessage');
if (successMessage) {
successMessage.style.display = 'none';
}
}

// Также добавим обработку нажатия Escape для закрытия сообщения
document.addEventListener('keydown', function(e) {
if (e.key === 'Escape') {
closeSuccessMessage();
}
});